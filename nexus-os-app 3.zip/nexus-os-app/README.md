# NEXUS OS v9.0

A futuristic AI-powered operating system interface built with Next.js 14.

![NEXUS OS](https://img.shields.io/badge/Version-9.0.0-cyan)
![Next.js](https://img.shields.io/badge/Next.js-14.2-black)
![Node.js](https://img.shields.io/badge/Node.js->=17.9.1-green)
![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-38B2AC)

## ⚙️ Requirements

- **Node.js**: >= 17.9.1 (supports 17.9.1, 18.x, 19.x, 20.x)
- **npm**: >= 8.0.0

## 🚀 Quick Start

### Option 1: Using npm

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

### Option 2: Using bun (faster)

```bash
# Install dependencies
bun install

# Run development server
bun run dev

# Build for production
bun run build

# Start production server
bun start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## ✨ Features

| Module | Description |
|--------|-------------|
| 🚀 **Boot Sequence** | Animated boot screen with matrix rain effect |
| 📊 **Dashboard** | Real-time system metrics and feature overview |
| 🎨 **Image Generation** | AI-powered image synthesis |
| 💻 **IDE** | Built-in code editor with syntax highlighting |
| ⌨️ **CLI Terminal** | Full-featured command-line interface |
| 💬 **AI Chat** | Intelligent assistant interface |
| 🔧 **Settings** | System configuration with persistence |

## 🛠️ Tech Stack

- **Framework**: Next.js 14 with App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: Radix UI
- **Animations**: CSS Keyframes + Tailwind

## 📁 Project Structure

```
nexus-os-app/
├── src/
│   ├── app/
│   │   ├── page.tsx        # Main application
│   │   ├── layout.tsx      # Root layout
│   │   └── globals.css     # Global styles
│   └── lib/
│       └── utils.ts        # Utility functions
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── next.config.ts
```

## 🎨 Customization

### Colors

The application uses a cyberpunk color scheme:

- **Cyan**: `#00f0ff` (Primary)
- **Magenta**: `#ff00aa` (Accent)
- **Green**: `#00ff88` (Success)
- **Yellow**: `#fbbf24` (Warning)

### Terminal Commands

The CLI supports these built-in commands:

- `help` - Show available commands
- `status` - Display system status
- `neofetch` - System information
- `matrix` - Enter the matrix
- `scan` - Scan for threats
- `evolve` - Trigger AI evolution
- `about` - About NEXUS OS
- `clear` - Clear terminal

## 📝 License

MIT License - NEXUS Corporation

---

*"The future is sentient."*
