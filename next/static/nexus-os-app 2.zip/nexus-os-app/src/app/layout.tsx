import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import './globals.css'

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
})

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
})

export const metadata: Metadata = {
  title: 'NEXUS OS - AI-Powered Operating System',
  description: 'A futuristic AI-powered operating system interface with quantum computing capabilities',
  keywords: ['NEXUS OS', 'AI', 'Quantum', 'Operating System', 'Future Tech'],
  authors: [{ name: 'NEXUS Corporation' }],
  openGraph: {
    title: 'NEXUS OS v9.0',
    description: 'The world\'s first sentient operating system',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} font-sans antialiased bg-background text-foreground`}
      >
        {children}
      </body>
    </html>
  )
}
