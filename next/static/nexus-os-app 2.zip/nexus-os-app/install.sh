#!/bin/bash

echo "╔══════════════════════════════════════╗"
echo "║     NEXUS OS Installation            ║"
echo "║     Version 9.0.0                    ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Check for package manager
if command -v bun &> /dev/null; then
    echo "✓ Using bun (fast)"
    PKG_MANAGER="bun"
elif command -v npm &> /dev/null; then
    echo "✓ Using npm"
    PKG_MANAGER="npm"
else
    echo "✗ No package manager found. Please install npm or bun."
    exit 1
fi

echo ""
echo "Installing dependencies..."
$PKG_MANAGER install

echo ""
echo "╔══════════════════════════════════════╗"
echo "║     Installation Complete!           ║"
echo "╚══════════════════════════════════════╝"
echo ""
echo "To start the development server:"
echo "  $PKG_MANAGER run dev"
echo ""
echo "Then open http://localhost:3000"
